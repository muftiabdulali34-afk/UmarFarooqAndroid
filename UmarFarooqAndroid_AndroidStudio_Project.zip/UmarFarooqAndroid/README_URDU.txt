# جامع مسجد عمر فاروق رضی اللہ عنہ — Android App

یہ Android Studio project موجودہ Offline HTML ایپ کو Android WebView میں پیک کرتا ہے۔

خصوصیات:
- Offline طلباء مینجمنٹ
- طلباء پروفائل اور تصویر
- حاضری
- فیس
- ماہانہ ٹیسٹ
- ماہانہ رپورٹ
- Android camera/file chooser integration

اہم: APK بنانے کے لیے Android Studio اور Android SDK درکار ہیں۔
Project کھولیں، Gradle sync کریں، پھر Build > Build APK(s) منتخب کریں۔

دوسرے ساتھیوں کے فون پر APK انسٹال کیا جا سکتا ہے، لیکن موجودہ ورژن میں ہر فون کا ڈیٹا الگ ہوگا؛ فونز کے درمیان خودکار data sync شامل نہیں ہے۔
